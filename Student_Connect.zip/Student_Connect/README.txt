STUDENT CONNECT — STARTER APP

Files:
- index.html: responsive student app prototype

How to try it on Android:
1. Extract the ZIP file using your phone's Files app.
2. Open index.html with Chrome or another browser.
3. Use Home, Notes, Tasks, Schedule and Profile.
4. Notes, assignments, schedule and posts are saved locally in that browser on that device.

Important:
This is a working front-end prototype, not a published Play Store app.
It does not yet have online accounts, cloud sync, public student posts, file uploads, or real college notifications.
To launch it for all students, the next step is hosting plus a backend/database and proper privacy/security rules.
